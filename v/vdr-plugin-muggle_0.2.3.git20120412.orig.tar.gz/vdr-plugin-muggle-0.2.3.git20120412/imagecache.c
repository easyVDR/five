/*								-*- c++ -*-
 * borrowed from vdr-text2skin
 */

#include "imagecache.h"
