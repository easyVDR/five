#!/usr/bin/env python

import dbus, gobject, avahi
from dbus import DBusException
from dbus.mainloop.glib import DBusGMainLoop

# Looks for streamdev-servers
TYPE = '_vdr_streamdev_server._sub._http._tcp'

def service_resolved(*args):
    print 'service resolved'
    print 'name:', args[2]
    print 'address:', args[7]
    print 'port:', args[8]
    Setup = bus.get_object('de.tvdr.vdr', '/Setup')
    Setup.Set('streamdev-client.RemoteIp', args[7], dbus_interface = 'de.tvdr.vdr.setup')
    Setup.Set('streamdev-client.RemotePort', args[8], dbus_interface = 'de.tvdr.vdr.setup')

def print_error(*args):
    print 'error_handler'
    print args[0]
    
def myhandler(interface, protocol, name, stype, domain, flags):
    print "Found service '%s' type '%s' domain '%s' " % (name, stype, domain)

    if flags & avahi.LOOKUP_RESULT_LOCAL:
            # local service, skip
            pass
    else:
            server.ResolveService(interface, protocol, name, stype, 
                domain, avahi.PROTO_UNSPEC, dbus.UInt32(0), 
                reply_handler=service_resolved, error_handler=print_error)


loop = DBusGMainLoop()

bus = dbus.SystemBus(mainloop=loop)

server = dbus.Interface( bus.get_object(avahi.DBUS_NAME, '/'),
        'org.freedesktop.Avahi.Server')

sbrowser = dbus.Interface(bus.get_object(avahi.DBUS_NAME,
        server.ServiceBrowserNew(avahi.IF_UNSPEC,
            avahi.PROTO_INET, TYPE, 'local', dbus.UInt32(0))),
        avahi.DBUS_INTERFACE_SERVICE_BROWSER)

sbrowser.connect_to_signal("ItemNew", myhandler)

gobject.MainLoop().run()

