/*
 * See the files COPYING and README for copyright information and how to reach
 * the author.
 *
 *  $Id: etsi-const.c,v 1.2 2006/06/25 18:20:27 lordjaxom Exp $
 */

#include "etsi-const.h"
#if 0
namespace etsi_const
{

	namespace component_type
	{
		const char* videoStrings[count] =
				{ "", "4:3", "16:9", "16:9", "21:9", "4:3", "16:9", "16:9", "21:9" };

		const char* audioStrings[count] =
				{ "", "Mono", "Dual-Channel", "Stereo", "Multilanguage", "Multichannel" };
	}

}
#endif
