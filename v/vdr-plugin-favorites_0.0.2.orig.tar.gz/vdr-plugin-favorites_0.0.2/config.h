#ifndef __FAVORITERCONFIG_H
#define __FAVORITECONFIG_H

struct sFavoriteConfig
{
   int closeonswitch;
   int sortby;
   int hidemainmenuentry;
};

extern sFavoriteConfig config;
#endif                           //__FAVORITERCONFIG_H
