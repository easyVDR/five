/*
 * See the README file for copyright information and how to reach the author.
 */

#include <vdr/plugin.h>
#include <vdr/menu.h>
#include <vdr/status.h>
#include <vdr/interface.h>
