/*
 * i18n.c: Internationalization
 *
 * See the README file for copyright information and how to reach the author.
 *
 * $Id: i18n.c 481 2005-06-02 00:12:13Z udo $
 */

#include "i18n.h"

#if VDRVERSNUM < 10507
const tI18nPhrase tlPhrases[] = {
// START I18N
// END I18N
  { NULL }
  };
#endif
