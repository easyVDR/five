#!/bin/sh
hg push ssh://root@www.uli-eckhardt.de//hg/autostart
