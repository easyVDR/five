/*
 *  HID driver for MS-Tech Case Remotes
 *
 *  Copyright (c) 2011 H. Pannenbaecker
 *  based on lcpower module
 *
 *  The driver supports USB IR modules in MS-Tech cases detected as HID devices
 *  working with the vendor's remote control.
 *
 *  [1d57:ac01] USB IR Receiver found in MS-Tech MC-1200 Rev.C case
 */

/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 */

#include <linux/device.h>
#include <linux/hid.h>
#include <linux/module.h>

#define USB_VENDOR_ID_MSTECH_1200_C	0x1d57
#define USB_DEVICE_ID_MSTECH_1200_C	0xac01

#define mstech_map_key_clear(c) hid_map_usage_clear(hi, usage, bit, max, \
						EV_KEY, (c))

static int mstech_input_mapping(struct hid_device *hdev, struct hid_input *hi,
		struct hid_field *field, struct hid_usage *usage,
		unsigned long **bit, int *max)
{
	if ((usage->hid & HID_USAGE_PAGE) != HID_UP_LOGIVENDOR)
		return 0;
/* 
	Map the "missing" keys
*/
	switch (usage->hid & HID_USAGE) {
	case 0x000d:	mstech_map_key_clear(KEY_HOME);		break;	// The "green" start button
        case 0x004a:    mstech_map_key_clear(KEY_RED);          break;	// Red
	case 0x0047:	mstech_map_key_clear(KEY_GREEN);	break;	// Green
        case 0x0049: 	mstech_map_key_clear(KEY_YELLOW);       break;	// Yellow
        case 0x0025: 	mstech_map_key_clear(KEY_BLUE);     	break;	// Blue
	case 0x0046: 	mstech_map_key_clear(KEY_VCR);		break;	// RecordTV

        default:
        	return 0;
	}

	return 1;
}

static const struct hid_device_id mstech_devices[] = {
	{ HID_USB_DEVICE( USB_VENDOR_ID_MSTECH_1200_C, USB_DEVICE_ID_MSTECH_1200_C ) },
	{ }
};
MODULE_DEVICE_TABLE(hid, mstech_devices);

static struct hid_driver mstech_driver = {
	.name = "hid-mstech",
	.id_table = mstech_devices,
	.input_mapping = mstech_input_mapping,
};

static int __init mstech_init(void)
{
	return hid_register_driver(&mstech_driver);
}

static void __exit mstech_exit(void)
{
       	hid_unregister_driver(&mstech_driver);
}

module_init(mstech_init);
module_exit(mstech_exit);
MODULE_LICENSE("GPL");
