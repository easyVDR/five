#ifdef LINUX

#include "../../Common/remote.h"



int OpenUSBPort (void)
{
}

int	ReadUSBString (byte pnt[],int len,word timeout)
{
}

void FlushUSB (void)
{
}

void WriteUSBString (byte pnt[],int len)
{
}



#endif


