#ifndef __MEDIACLIENT_H
#define __MEDIACLIENT_H

#include <poll.h>
#include "mediacmds.h"
#include "videodev2.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __FINAL_LIBMEDIACLIENT
#define EXPORT __attribute__((visibility("hidden")))
#else
#define EXPORT __attribute__((visibility("default")))
#endif

/* opens a control channel to the media daemon */
EXPORT int net_open(char *node, int flags);

/* unlocked open, do not use */
EXPORT int net_open_internal(char *node, int flags);

/* send ioctl messages to the media daemon */
#if defined(__OPENWRT_MIPS_DDWRT__) || defined(__OPENWRT_PPC__)
EXPORT int net_ioctl(int fd, int cmd, void *data);
#else
EXPORT int net_ioctl(int fd, unsigned int cmd, void *data);
#endif

/* disconnect from media daemon */
EXPORT int net_close(int fd);

/* handle for the dvr dvb device */
EXPORT ssize_t __net_read(int fd, void *buf, size_t nbytes);

/* handle for video4linux */
EXPORT void *net_mmap(void *addr, size_t length, int prot, int flags, int fd, off_t offset);

/* memory mapping handle for video4linux */
EXPORT int net_munmap(void *_start, size_t length);

/* triggers the daemon to check if there are any new devices, usually
 * done by udev */
EXPORT int net_update_devices(uint8_t status, char *pluginpath, char *serverpath, char *configfile, int block, int nonodes);

/* device enumeration, only takes devices into account which are supported
 * by the new framework, id .. deviceid (might be incremented by the driver), 
   subid .. subid esp. for digital tv */
EXPORT struct media_device_enum *net_device_enum(int fd, int *id, int subid);

/* connects to the daemon supported parameter O_CLOEXEC */
EXPORT int net_connect(int flags);

#define NET_AUDIO_STOP 1
EXPORT ssize_t net_audio_option(int fd, int option);

/* interrupt read() */
EXPORT int net_abort_read(int fd);

/* can be used to determine the current buffersize of the dvr node */
EXPORT int net_getbufsize(int fd);

EXPORT int net_clear_signalfd(int fd);

EXPORT struct media_pids *net_get_processlist(int fd, char *nodename);

EXPORT int net_disconnect_pid(pid_t pid);

/* aspect_ratio values for wss_data */
enum {
	WSS_4_3_FULL              = 8,
	WSS_14_9_LETTERBOX_CENTRE = 1,
	WSS_14_9_LETTERBOX_TOP    = 2,
	WSS_16_9_LETTERBOX_CENTRE = 11,
	WSS_16_9_LETTERBOX_TOP    = 4,
	WSS_16_9_LETTERBOX_DEEPER = 13,
	WSS_14_9_FULL_HEIGHT_4_3  = 14,
	WSS_16_9_FULL_HEIGHT_16_9 = 7,
	WSS_UNABLE_TO_DEMODULATE  = 255
};
/* 
 * For further details about the data struct please refer to:
 * http://en.wikipedia.org/wiki/Widescreen_signaling
 */

struct wss_data {
	uint8_t aspect_ratio; 
/* other values are currently not implemented, can be supplied uppon request */
	uint8_t b04;
	uint8_t b05;
	uint8_t b06;
	uint8_t b07;
	uint8_t b08;
	uint8_t subtitles;
	uint8_t b11;
	uint8_t b12;
	uint8_t b13;
};

EXPORT int net_register_wss(char *vbi, int (*wss_callback)(void *priv, struct wss_data *wss), void *priv);

/* net_decode_wss will trigger the wss_callback,
   please note that not every call will trigger the callback
 */

EXPORT int net_decode_wss(int wssfd);

EXPORT int net_unregister_wss(int wssfd);

EXPORT int net_dup(int fd);

EXPORT int net_poll(struct pollfd *__fds, nfds_t __nfds, int __timeout);

EXPORT int net_mount_device(uint8_t *path, int type);

/* enable/disable listning on the network */
EXPORT int net_enablenetwork(int flag);

/* let the enduser set the API version (implemented since w-scan is usually bound to a specific DVB API ver) */
EXPORT int net_set_apiver(int major, int minor);

/* mostly for analog TV, where to read the statistics from (has no effect with devices which do not support it */
/* 0 .. default read from videodecoder */
/* 1 .. read from demodulator */
EXPORT int net_set_signalstatistics(int option); /* depreciated, directly use net_srv_cmd */

EXPORT int net_srv_cmd(uint8_t cmd, uint32_t option);

/* this allows to check if a filedescriptor is currently owned by the media framework */
EXPORT int net_checkfd(int fd);

/* Device ATTACH/DETACH devicenotification */
/* retrieve pollable filedescriptor */
EXPORT int net_register_notification();

/* check which device ID was attached or detached */
EXPORT struct media_device_notification *net_read_notification(int fd);

/* unregister notification service */
EXPORT void net_close_notification(int fd);

EXPORT int net_dump_tracer();
EXPORT int atv_set_vmode(int fd, uint8_t *vmode, v4l2_std_id *id);
EXPORT int net_dummy(uint8_t action, int id);
#if defined(_NET_READ)
EXPORT ssize_t net_read(int fd, void *buf, size_t nbytes);
#endif
#ifdef __cplusplus
}
#endif

EXPORT int net_driver_shutdown();


/* this interface can be used in order to improve support for virtualized
 * device drivers which run on application layer rather than kernel layer
 *
 * examples for such devices are:
 *  * Sundtek based TV Tuners (Network based and Local)
 *  * Reel Multimedia Netceivers
 *  * HD Homerun
 *  * and others.
 *
 * Reference code can be found at:
 * http://sundtek.de/support/e2plugin.tar.gz
 **/

/* E2 plugin, version 1.0 */
struct quickzap_ops {
	uint16_t version;   /* API Version */
	uint8_t name[100];  /* Plugin Name */
	int     (*open)  (const char *pathname, int flags, mode_t mode);        /* open  */
	int     (*ioctl) (int fd, unsigned long int request, ...);   /* ioctl */
	ssize_t (*read)  (int fd, void *buf, size_t count);  /* read  */
	ssize_t (*write) (int fd, void *buf, size_t count);  /* write */
	int     (*close) (int fd);  /* close */
	int     (*exists)(int id);  /* stat alternative */
	int     (*get_adapter)(char *path, int id);
	int     (*access)(const char *path, int amode);
} __attribute__((packed));

EXPORT int net_disable_adapter(char *nodename, int disabled);

struct rds_data {
	int fd;
	uint8_t radiotext[150];
	uint8_t program[20];
	uint8_t rdsbuf[8];
	uint8_t brkstat;
};
EXPORT int media_install_streamer(char *proxy, char *dstpath, int showlink);

#endif
