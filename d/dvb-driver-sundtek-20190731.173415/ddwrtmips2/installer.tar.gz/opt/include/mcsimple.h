#ifndef _MC_SIMPLE_H
#define _MC_SIMPLE_H

/* mediaclient simple interface, fd's need to be opened with net_open and closed with net_close */

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <sys/stat.h>
#include <string.h>
#include "frontend.h"
#include "videodev2.h"

#ifdef __cplusplus
extern "C" {
#endif
#define EXPORT __attribute__((visibility("default")))

EXPORT int set_mute(int fd, char *arg);
EXPORT int ir_enum_devices(int fd);
EXPORT int ir_set_rc(int fd, int id);
EXPORT int ir_read_rc(int fd);
EXPORT int media_print_clients(int fd, char *name);
EXPORT int media_list_clients();
EXPORT int print_driver_info(char *device);
EXPORT int enum_devices(int fd);
EXPORT int set_intaudio(int fd, uint8_t *opt);
EXPORT int get_properties(int fd);
EXPORT int set_dtvmode(int fd, uint8_t *mode);
EXPORT int set_dvbs_channel(int fd, char *modtype, uint64_t frequency, uint32_t symbol_rate, uint8_t *modulation, char *voltage, char *fec, char *band, fe_rolloff_t rolloff, int verbose);
EXPORT int set_dvbc_channel(int fd, uint32_t frequency, uint32_t symbol_rate, uint8_t *modulation);
EXPORT int set_isdbt_channel(int fd, uint32_t frequency);
EXPORT int set_dvbt_channel(int fd, uint32_t frequency, uint32_t bandwidth);
EXPORT int set_atsc_channel(int fd, uint32_t frequency);
EXPORT int set_atsc_qam_channel(int fd, uint32_t frequency, uint8_t *modulation);
EXPORT int dvb_list_pids(int fd);
EXPORT int dvb_add_pids(int fd, uint16_t pid);
EXPORT int dvb_del_pid(int fd, uint16_t pid);
EXPORT int dvb_flushpids(int fd);
EXPORT int dvb_hw_pidfilter(int fd, int enable);
EXPORT int set_radio_channel(int fd, int frequency, int tuner);
EXPORT int set_atv_channel(int fd, int frequency, char *standard);
EXPORT int atv_list_standards(int fd);
EXPORT int atv_list_inputs(int fd);
EXPORT int atv_list_areas(int fd);
EXPORT int atv_set_area(int fd, uint8_t *area);
EXPORT int atv_set_vmode(int fd, uint8_t *vmode, v4l2_std_id *id);
EXPORT int atv_set_input(int fd, uint8_t *input);
EXPORT int get_lock(int fd);
EXPORT int get_lock_extended(int fd, int silent);
EXPORT int get_analog_lock(int fd);
EXPORT int v4l_set_vfilter(int fd, char *vfilter);
EXPORT int v4l_set_vfilterid(int fd, int id);
EXPORT int media_disconnect_process(pid_t process);
EXPORT int media_unmount_device(uint8_t *path, uint8_t silent);
EXPORT int media_mount_device(uint8_t *path, uint8_t silent);
EXPORT int media_add_dummy();
EXPORT int media_del_dummy(int id);
EXPORT int media_enablenetwork(char *flag);
EXPORT int set_apiversion(char *apiversion);
EXPORT int set_signalstatistics(int option);
EXPORT int net_dump_tracer(); /* only available in debug mode */
EXPORT int read_signal(int times, char *device, char *band, int interval);
EXPORT int media_set_crc(char *state);
EXPORT int media_set_loglevel(char *loglevel);
EXPORT int set_audiothreshold(int threshold);
EXPORT int media_set_transfermode(char *path, char *mode);
EXPORT int media_set_nullpackets(char *path, char *mode);
EXPORT int net_enabledreambox(char *enabledreambox);
EXPORT int net_disabledreambox(char *disabledreambox);
EXPORT int media_read_version(char *version);

/* void *media_scan_network
   ARGS:
   scanlist: 1 allocate deviceobject
             0 visible scan only
*/
EXPORT void *media_scan_network(int scanlist, unsigned int scandelay);
/* int media_scan_info
   ARGS:
   argv: deviceobject
   id: deviceid
   identifier: "devicename", "ip", "deviceid"
   retval: char pointer to char array for return value, will return
           to char element of deviceobject, do not free
*/
EXPORT int media_scan_info(void *argv, int id, char *identifier, void **retval);
/* int media_scan_free
   ARGS:
   pointer to device object for deallocation
*/
EXPORT int media_scan_free(void **arg);
EXPORT void *media_scan_network(int scanlist, unsigned int scannetworkdelay);
#if defined(EXPORT_QZ_OPS)
EXPORT struct quickzap_ops qz_ops;
#endif
EXPORT char *media_build_version();

/* requires to include mediaclient.h first */
EXPORT struct rds_data *media_open_rds(uint8_t *rdspath);
EXPORT int media_read_rds(struct rds_data *rdsd);
EXPORT int media_close_rds(struct rds_data *rdsd);

#ifdef __cplusplus
}
#endif
#endif
