/* ******************************** */
/* Sundtek MediaTV Player Framework */
/* Copyright 2013 Sundtek LTD.      */
/* ******************************** */

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#if defined(__CYGWIN__)
#define __USE_LINUX_IOCTL_DEFS
#include <sys/ioctl.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define EXPORT __attribute__((visibility("default")))

/* player_init_10
   initialize player structure
*/
EXPORT struct PlayerDev *player_init_10();

/* player_set_loglevel_10
   dev .. player handle
   loglevel .. set loglevel
   LOG_VERBOSE will print some information to stdout (also error messages)
*/
EXPORT int player_set_loglevel_10(struct PlayerDev *dev, uint8_t loglevel);
#define PLAYER_LOG_OFF 0
#define PLAYER_LOG_VERBOSE 1

/* player_open_10
   dev .. player handle
   node .. device node
*/
EXPORT int player_open_10(struct PlayerDev *dev, char *node);

struct video_standards {
	uint8_t n_standards;
	uint32_t *standards;
};
/*  player_get_standard_10
    dev .. player handle
    return:
    video_standards
*/
EXPORT struct video_standards *player_get_standard_10(struct PlayerDev *dev);

#define MEDIA_STD_PAL_B          ((uint32_t)0x00000001)
#define MEDIA_STD_PAL_B1         ((uint32_t)0x00000002)
#define MEDIA_STD_PAL_G          ((uint32_t)0x00000004)
#define MEDIA_STD_PAL_H          ((uint32_t)0x00000008)
#define MEDIA_STD_PAL_I          ((uint32_t)0x00000010)
#define MEDIA_STD_PAL_D          ((uint32_t)0x00000020)
#define MEDIA_STD_PAL_D1         ((uint32_t)0x00000040)
#define MEDIA_STD_PAL_K          ((uint32_t)0x00000080)

#define MEDIA_STD_PAL_M          ((uint32_t)0x00000100)
#define MEDIA_STD_PAL_N          ((uint32_t)0x00000200)
#define MEDIA_STD_PAL_Nc         ((uint32_t)0x00000400)
#define MEDIA_STD_PAL_60         ((uint32_t)0x00000800)

#define MEDIA_STD_NTSC_M         ((uint32_t)0x00001000)
#define MEDIA_STD_NTSC_M_JP      ((uint32_t)0x00002000)
#define MEDIA_STD_NTSC_443       ((uint32_t)0x00004000)
#define MEDIA_STD_NTSC_M_KR      ((uint32_t)0x00008000)

#define MEDIA_STD_SECAM_B        ((uint32_t)0x00010000)
#define MEDIA_STD_SECAM_D        ((uint32_t)0x00020000)
#define MEDIA_STD_SECAM_G        ((uint32_t)0x00040000)
#define MEDIA_STD_SECAM_H        ((uint32_t)0x00080000)
#define MEDIA_STD_SECAM_K        ((uint32_t)0x00100000)
#define MEDIA_STD_SECAM_K1       ((uint32_t)0x00200000)
#define MEDIA_STD_SECAM_L        ((uint32_t)0x00400000)
#define MEDIA_STD_SECAM_LC       ((uint32_t)0x00800000)

#define MEDIA_STD_MN	(MEDIA_STD_PAL_M|MEDIA_STD_PAL_N|MEDIA_STD_PAL_Nc|MEDIA_STD_NTSC)
#define MEDIA_STD_B	(MEDIA_STD_PAL_B|MEDIA_STD_PAL_B1|MEDIA_STD_SECAM_B)
#define MEDIA_STD_GH	(MEDIA_STD_PAL_G|MEDIA_STD_PAL_H|MEDIA_STD_SECAM_G|MEDIA_STD_SECAM_H)
#define MEDIA_STD_DK	(MEDIA_STD_PAL_DK|MEDIA_STD_SECAM_DK)

/* some common needed stuff */
#define MEDIA_STD_PAL_BG	(MEDIA_STD_PAL_B		|\
				 MEDIA_STD_PAL_B1	|\
				 MEDIA_STD_PAL_G)
#define MEDIA_STD_PAL_DK	(MEDIA_STD_PAL_D		|\
				 MEDIA_STD_PAL_D1	|\
				 MEDIA_STD_PAL_K)
#define MEDIA_STD_PAL		(MEDIA_STD_PAL_BG	|\
				 MEDIA_STD_PAL_DK	|\
				 MEDIA_STD_PAL_H		|\
				 MEDIA_STD_PAL_I)
#define MEDIA_STD_NTSC           (MEDIA_STD_NTSC_M	|\
				 MEDIA_STD_NTSC_M_JP     |\
				 MEDIA_STD_NTSC_M_KR)
#define MEDIA_STD_SECAM_DK      (MEDIA_STD_SECAM_D	|\
				 MEDIA_STD_SECAM_K	|\
				 MEDIA_STD_SECAM_K1)
#define MEDIA_STD_SECAM		(MEDIA_STD_SECAM_B	|\
				 MEDIA_STD_SECAM_G	|\
				 MEDIA_STD_SECAM_H	|\
				 MEDIA_STD_SECAM_DK	|\
				 MEDIA_STD_SECAM_L       |\
				 MEDIA_STD_SECAM_LC)

#define MEDIA_STD_525_60	(MEDIA_STD_PAL_M		|\
				 MEDIA_STD_PAL_60	|\
				 MEDIA_STD_NTSC		|\
				 MEDIA_STD_NTSC_443)
#define MEDIA_STD_625_50	(MEDIA_STD_PAL		|\
				 MEDIA_STD_PAL_N		|\
				 MEDIA_STD_PAL_Nc	|\
				 MEDIA_STD_SECAM)

#define MEDIA_STD_UNKNOWN        0
#define MEDIA_STD_ALL            (MEDIA_STD_525_60	|\
				 MEDIA_STD_625_50)

/*  player_set_standard_10
    dev .. player handle
    std .. set videostandard
*/
EXPORT int player_set_standard_10(struct PlayerDev *dev, uint32_t std);

/* player_setup_10
   dev .. player handle
   std .. video4linux2 standard
   width .. width
   height .. height
   set up video tuner parameters
*/
EXPORT int player_setup_10(struct PlayerDev *dev, uint32_t width, uint32_t height);


/* player_get_shader_10
   retrieve the shader which can be used with the current video format
   * YUV422 -> RGB
   or
   * UYVY -> RGB
   the returned shader depends on which device is used
*/
EXPORT char *player_get_shader_10(struct PlayerDev *dev);


/*  player_start_stream
    dev .. player handle
    start video streaming
*/
EXPORT int player_start_stream_10(struct PlayerDev *dev);

/*  player_stop_stream
    dev .. player handle
    stop video streaming
*/
EXPORT int player_stop_stream_10(struct PlayerDev *dev);


struct video_buffer {
	void *data; /* video frame */
	int length; /* length */
	void *priv; /* internal use don't touch */
};
/*  player_put_frame_10
    return buffer to player engine
*/
EXPORT int player_put_frame_10(struct PlayerDev *dev, struct video_buffer *buf);


/*  player_get_frame_10
    try to obtain a video frame, if no frame is available the function
    will return NULL
*/
EXPORT struct video_buffer *player_get_frame_10(struct PlayerDev *dev);

/*  player_get_input_10
    dev .. player handle
    retrieve player inputs
*/
EXPORT struct player_inputs *player_get_inputs_10(struct PlayerDev *dev);
struct player_inputs {
	uint8_t n_inputs;
	struct {
		uint8_t id;
		uint8_t name[32];
		uint32_t type;
	} **inputs;
};


/*  player_set_input_10
    dev .. player handle
    input .. input id retrieved by player_get_inputs
*/
EXPORT int player_set_input_10(struct PlayerDev *dev, uint8_t input);

/*  player_set_frequency
    dev .. player handle
    frequency .. frequency in khz
*/
EXPORT int player_set_frequency_10(struct PlayerDev *dev, uint32_t frequency);

/*  player_get_frequency
    dev .. player handle
    frequency .. pointer frequency in khz
*/
EXPORT int player_get_frequency_10(struct PlayerDev *dev, uint32_t *frequency);

/*
    player_signal_status_10
    dev .. player handle
    status .. signal status
*/
EXPORT int player_signal_status_10(struct PlayerDev *dev, uint8_t *status);
#define VIDEO_UNLOCKED 0
#define VIDEO_LOCKED 1

/*
    player_set_audiomode
    dev .. player handle
    mode .. internal or external audio playback
*/

EXPORT int player_set_audiomode_10(struct PlayerDev *dev, uint8_t mode);
#define INTERNAL_AUDIO 0
#define EXTERNAL_AUDIO 1

/*
    player_close_10
    dev .. player handle
    close device nodes
*/
EXPORT int player_close_10(struct PlayerDev *dev);

/*
    player_set_shader_workaround
    dev .. player handle
    mode .. set GL_WORKAROUND to enable the shader workaround
*/
EXPORT int player_set_shader_workaround(struct PlayerDev *dev, uint8_t mode);
#define GL_NORMAL     0
#define GL_WORKAROUND 1
