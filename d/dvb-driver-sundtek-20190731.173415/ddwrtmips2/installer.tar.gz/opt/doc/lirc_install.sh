#!/bin/bash
echo ""
echo "Do you want to install a preconfigured remote control setup for"
echo "Sundtek MediaTV? [Y/N]"
echo ""
echo "Wollen Sie die vorkonfigurierte Einstellungen für die"
echo "Sundtek MediaTV Fernbedienung installieren? [J/N]"
read a
if [ "$a" = "y" ] || [ "$a" = "j" ] || [ "$a" = "Y" ] || [ "$a" = "J" ]; then
	echo "Copying preconfigured lirc setup from /opt/doc to /etc/lirc"
	mkdir -p /etc/lirc
	cp /opt/doc/hardware.conf /etc/lirc
	cp /opt/doc/sundtek.conf /etc/lirc
	echo "done..."
	echo "restarting lirc"
	/opt/bin/lirc.sh ATTACH
	echo "done..."
	echo "now you can test lirc by running irw"
	echo "KDE also offers irkick for a comfortable graphical configuration"
	echo ""
else
	echo "installation aborted ..."
fi
