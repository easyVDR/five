#ifndef _MEDIA_CMDS_H
#define _MEDIA_CMDS_H
#include <inttypes.h>
#include <stdint.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include "frontend.h"

#ifdef __cplusplus
extern "C" {
#endif
/* DVB-S/S2 custom commands */

#define DTV_START  1000
#define DTV_COMMIT 1001


#define MEDIA_CMD_IOCTL32 1
#define MEDIA_CMD_IOCTL64 2
#define MEDIA_CMD_EIOCTL  3 /* extended ioctls */
#define MEDIA_CMD_OPEN    4 
#define MEDIA_CMD_ENUM    5
#define MEDIA_CMD_PING    6
#define MEDIA_CMD_NOTIFY  7
#define MEDIA_CMD_MMAP    8
#define MEDIA_CMD_OPEN_SIGNAL_FD 9
#define MEDIA_CMD_ATTACH_SIGNAL_FD 10
#define MEDIA_CMD_ATTACH_RBFD 11


struct media_device_notification {
	uint8_t cmd;
	uint8_t status;
#define DEVICE_ATTACHED 1
#define DEVICE_DETACHED 2
	uint32_t deviceid;
	uint8_t serial[75];
} __attribute__ ((packed));

#define NET_EIOCTL_UNHANDLED -1
#define NET_EIOCTL_HANDLED    0

/* extended frontend commands */
#define FE_GET_API_VERSION         1
#define FE_SET_DEVICE_MODE         2
#define BRIDGE_SET_DEVICE_MODE     3 /* might be merged with FE_SET_DEVICE_MODE ? */
/* infrared control */
#define DEVICE_CONFIG_IR       4
#define DEVICE_ENUM_IR         5
#define DEVICE_REPORT_IR       6 /* TODO: interrupt driven rc reading */
#define DEVICE_READ_IR         7 /* read current rc key */
#define BRIDGE_SET_PID_FILTER  8
#define BRIDGE_GET_PID_FILTER  9

struct media_pid_filter {
	uint8_t id;
	uint8_t enabled;
	uint16_t pid;
} __attribute__ ((packed));

#define BRIDGE_SET_HW_FILTER   10
#define BRIDGE_GET_HW_FILTER   11

struct media_hw_filter {
	uint8_t enabled;
};

#define DEVICE_SET_AREA_HINT  12
#define DEVICE_GET_AREA_HINT  13

struct media_area_hint {
	uint8_t id;
	uint8_t enabled;
	uint8_t area[50];
} __attribute__ ((packed));

/* flush pid filters and disable hw pid filtering */
#define BRIDGE_FLUSH_PIDS      14

/* set audioprocessing, if it should be handled by the driver or will be
 * handled by an external application */

#define VIDIOC_S_AUDIOPROCESSING 15
#define VIDIOC_G_AUDIOPROCESSING 16

struct video_audioprocessing{
	uint8_t intaudio;
#define MEDIA_AUDIO_AUTO      0
#define MEDIA_AUDIO_INTERNAL  1
#define MEDIA_AUDIO_EXTERNAL  2
#define MEDIA_AUDIO_ONLY      3
	uint8_t enable;
} __attribute__((packed));

/* set application hint, used for automatic detection if audio
 * should be handled by the driver */

#define VIDIOC_S_APPHINT 17

struct vidio_apphint {
	uint8_t playerid;
#define MEDIA_APP_UNDEFINED 0
#define MEDIA_APP_TVTIME    1
#define MEDIA_APP_CAMORAMA  2
};

/* get streamstate */

#define VIDIOC_G_STREAMSTATE 18

struct vidioc_streamstate {
	uint8_t state;
#define MEDIA_STREAMOFF 0
#define MEDIA_STREAMON  1
};

/* g_tuner/s_tuner extension, get the current active tuner, argument v4l2_tuner */
#define VIDIOC_G_ACTIVETUNER 19

#define MEDIA_GET_REMOTE_ID 20

struct dvb_dmx_id {
	int32_t id;
};

/* this is for retrieving the shared memory ids of the driver instance */
#define MEDIA_TRANSFER_INFO 21
struct media_transfer_info {
	/* shared memory information */
	key_t dvb_shm_key;
	key_t atv_shm_key;
	key_t snd_shm_key;
	key_t vbi_shm_key;
	uint32_t flags;
#define MEDIA_DOWNSTREAM 0 
#define MEDIA_UPSTREAM   1
} __attribute__((packed));

/* switching DVB API Version */

/* TODO: add SET option */
#define MEDIA_SET_VERSION 22

struct media_set_version {
	uint8_t major_version; /* default will be DVB API v3, but can be set to anything */
	uint8_t minor_version;
};

#define FE_GET_SIGQUALITY 23
struct media_sigquality {
   uint16_t MER;                  /**< in steps of 0.1 dB                        */
   uint32_t preViterbiBER ;       /**< in steps of 1/scaleFactorBER              */
   uint32_t postViterbiBER ;      /**< in steps of 1/scaleFactorBER              */
   uint32_t scaleFactorBER;       /**< scale factor for BER                      */
   uint32_t packetError ;         /**< number of packet errors                   */
   uint32_t postReedSolomonBER ;  /**< in steps of 1/scaleFactorBER              */
   uint32_t indicator;            /**< indicative signal quality low=0..100=high */
} __attribute__((packed));

#define MEDIA_SET_VIDEOFILTER 24
struct media_videofilter {
	int16_t index;
	uint8_t type;
#define MEDIA_VIDEO_FILTER_DEFAULT 1
	uint8_t name[50];
	uint8_t enabled;
} __attribute__((packed));

#define MEDIA_GET_VIDEOFILTER 25

#define MEDIA_ENUM_VIDEOFILTER 26

#define MEDIA_CLOSE 27 /* only to speed up disconnection, not mandatory */

#define MEDIA_CMD_GET_PIDS 28

struct media_pid {
	pid_t pid;
	uint8_t enabled;
	uint16_t dvbpid;
} __attribute__((packed));

struct media_pids {
	uint8_t cmd;
	int32_t retval;
	uint32_t npids;	
	uint32_t fh_type;
	uint8_t node[50];
	struct media_pid pids[0]; /* variable length */
} __attribute__((packed));

#define MEDIA_CMD_DISCONNECT_CLIENT 29

struct media_client_disconnect {
	uint8_t cmd;
	pid_t pid;
} __attribute__((packed));

#define MEDIA_CMD_MOUNT_DEVICE 30

struct media_client_mount {
	uint8_t cmd;
	uint8_t path[50];
	uint8_t type;
#define MEDIA_UNMOUNT 0
#define MEDIA_MOUNT   1
} __attribute__((packed));

#define MEDIA_CMD_NETWORK 31

struct media_client_network {
	uint8_t cmd;
	uint8_t state;
#define MEDIA_NETWORK_DISABLE 0
#define MEDIA_NETWORK_ENABLE  1
} __attribute__((packed));

#define MEDIA_CMD_SETAPI 32

struct media_apiver {
	uint8_t cmd;
	uint8_t major;
	uint8_t minor;
} __attribute__((packed));

struct media_cmd_option {
	uint8_t cmd;
	uint32_t option;
} __attribute__((packed));

#define MEDIA_CMD_SETSIGSTAT  33

#define MEDIA_CMD_SET_CRC     34
#define MEDIA_CRC_ON 1
#define MEDIA_CRC_OFF 0

#define MEDIA_CMD_SET_LOGGING 35
#define MEDIA_LOGGING_OFF 0
#define MEDIA_LOGGING_MIN 1
#define MEDIA_LOGGING_MAX 2
	
#define MEDIA_CMD_SET_AUDIO_THRESHOLD 36
/* value 0 - 2000 */

#define MEDIA_CMD_NOTIFICATION 37 /* register a filehandle which will be notified when a device
                                     will be attached */

/* this reuses struct media_device_notification, and sends those structs to the client.
   net_device_enum can be used with the returned result */

#define FE_GET_TPS 38
enum {
   FE_TPS_FRAME1     = 0,                /**< TPS frame 1.       */
   FE_TPS_FRAME2,                        /**< TPS frame 2.       */
   FE_TPS_FRAME3,                        /**< TPS frame 3.       */
   FE_TPS_FRAME4,                        /**< TPS frame 4.       */
   FE_TPS_FRAME_UNKNOWN = 254    /**< TPS frame unknown. */
};

struct media_tps_info {
	fe_bandwidth_t      bandwidth;
	fe_code_rate_t      code_rate_HP;  /* high priority stream code rate */
	fe_code_rate_t      code_rate_LP;  /* low priority stream code rate */
	fe_modulation_t     constellation; /* modulation type (see above) */
	fe_transmit_mode_t  transmission_mode;
	fe_guard_interval_t guard_interval;
	fe_hierarchy_t      hierarchy_information;
	uint8_t fe_tpsframe;
	uint8_t length;
	uint16_t cellId;
} __attribute__((packed));

#define MEDIA_CMD_DUMMY 39
struct media_dummy_cmd {
	uint8_t cmd;
	uint8_t action;
#define MEDIA_CREATE 1
#define MEDIA_DELETE 2
	uint8_t id;
	uint32_t type;
#if 0
#define MEDIA_ANALOG_TV
#define MEDIA_DVBT
#define MEDIA_DVBC
#endif
} __attribute__((packed));

#define FE_SET_NULLPACKETS 40

struct fe_null_packets {
	uint8_t mode;
#define FE_NULL_PACKETS_FILTERED 0
#define FE_NULL_PACKETS_ON       1
};

#define MEDIA_DEVICE_SET_TRANSFER_MODE 41
struct media_device_transfer_mode {
	uint8_t mode;
#define MEDIA_TRANSFER_ISOC 0
#define MEDIA_TRANSFER_BULK 1
	uint32_t type;
/*
 * MEDIA_AUDIO
 * MEDIA_VIDEO
 * MEDIA_DIGITAL_TV
 */
};

/* for measuring purpose and for NXP TDA tuner only at this time (NXP register 02/03 Powerlevel */
#define FE_TUNER_POWERLEVEL 42
/* uint32_t powerlevel; */

#if defined(__linux__)
#define MEDIA_DREAMBOX 43
struct media_dreambox {
	uint8_t option;
#define ENABLE_DREAMBOX_SUPPORT  1
#define DISABLE_DREAMBOX_SUPPORT 2 
	uint8_t path[100];
} __attribute__((packed));
#endif

#define FE_GET_VERSION 44
struct fe_driver_version {
	uint8_t version[1024];
} __attribute__((packed));

#undef s_addr
struct _in_addr {
        uint32_t s_addr;
};

/* get remote TCP port */
#define FE_GET_DVR_PORT 45
struct media_dvr_port {
        uint32_t port;
        struct _in_addr host;
} __attribute__((packed));

/* in case someone wants to grab MPEG-TS with an alternative client */
#define FE_STREAMON  46
#define FE_STREAMOFF 47


#define MEDIA_CMD_SHUTDOWN  48

#define FE_GET_DVR_DEV 49
//struct media_device_enum

/* don't use unless discussed with sundtek */
#define FE_I2C_RW 50
struct media_i2c_rw {
	uint16_t addr;
	uint8_t *wdata;
	uint16_t wcount;
	uint8_t wflags;
	uint8_t *rdata;
	uint16_t rcount;
	uint8_t rflags;
};

#define IOCTL_CMD_DLINE 51 // deadline for command default on (usually 10msec)/ arg int

#define FE_SET_SOFTFILTER 52
#define SOFTFILTER_OFF 0
#define SOFTFILTER_ON  1
#define SOFTFILTER_PASSTHROUGH 2

#define FE_START_TRANSFER 53 // enable mpeg output
#define FE_STOP_TRANSFER 54 // disable mpeg output

#define MEDIA_REMOTE_ENABLE 55
#define REMOTE_ENABLE  1
#define REMOTE_DISABLE 0

#define MEDIA_REMOTE_SET_RC 56
struct rc_key {
	uint16_t index;
	uint16_t rckey;
} __attribute__((packed));
#define MEDIA_REMOTE_GET_RC 57

#define FE_GET_VOLTAGE 58
#define FE_GET_TONE 59

#define MEDIA_READ 60
#define MEDIA_POLL 61

/* DVB-S/S2 ESNO
 * ioctl argument:
 *    pointer to uint16_t
*/

#define FE_READ_ESNO 62

#define FE_TUNER_CMD 63
struct media_tunercmd {
	uint8_t len; // max 64 write
	uint8_t cmd[64]; // in write / out read
	uint8_t readlen; // max 64 read
	uint8_t updatedefault;
} __attribute__((packed));

#define FE_SET_IFAGC 64
struct media_ifagc {
	uint8_t mode;
#define CTRL_AUTO 0
#define CTRL_OFF 1
#define CTRL_USER 2
	uint16_t value;
} __attribute__ ((packed));

#define FE_GET_IFAGC 65

#define FE_SET_RFAGC 66
struct media_rfagc {
	uint8_t mode; // same as IFAGC
	uint16_t value;
} __attribute__ ((packed));

#define FE_GET_RFAGC 66
	
#define DAB_SET_FREQUENCY 67
struct dab_frequency {
	uint32_t frequency;
	uint8_t sid_set;
	uint32_t sid;
	uint8_t comp_set;
	uint32_t comp;
} __attribute__((packed));

#define DAB_GET_TUNER 68
struct dab_tuner {
	uint32_t signalstrength;
	uint32_t status;
#define DAB_HAS_LOCK 0x01
        uint8_t rssi;
        uint8_t snr;
        uint8_t fic_quality;
        uint8_t cnr;
} __attribute__ ((packed));

#define DAB_ADD_SERVICE 69
struct dab_setup_service {
	uint8_t mode;
#define DAB_STREAM_MODE_AUDIO 0
#define DAB_PACKET_MODE       1
#define DAB_STREAM_MODE_DATA  2 /* not supported yet */
#define DAB_PLUS_MODE_AUDIO   3
	uint8_t SubChId;
	uint16_t StartCU;
	uint8_t UEP_EEP;
	uint8_t UEPTabldx;
	uint8_t EEPIdx; 
	uint16_t CUNum;
	uint16_t PacketAddr;
	uint8_t FECScheme;
} __attribute__ ((packed));

#define DAB_DEL_SERVICE 70
// use struct dab_service SubChId and PacketAddr

/* switch transfer mode between TCP/UDP */
#define MEDIA_SET_NET_TRANSFER_MODE 71
#define MEDIA_GET_NET_TRANSFER_MODE 72
struct media_net_transfer_mode {
	uint8_t transfer_mode;
#define MEDIA_TCP 0
#define MEDIA_UDP 1
};

/* in case of custom allocated UDP port redirect the videodata,
 * to given local port */
#define FE_SET_UDP_PORT 73
struct media_udp_port {
	uint16_t port;
};

/* this is used internally to avoid bugged shared memory buffers */
#define DVR_LOCAL_BUFFER 74

#define FE_SET_NTI 75
// argument int values range from 0 to 10000
//
//
#define MEDIA_CMD_DM_TIMING 76
#define MEDIA_TIMING_ON 1
#define MEDIA_TIMING_OFF 0

#define FE_SET_ALIAS 76
struct media_fe_alias {
	uint8_t name[50];
};

/* Media Network recovery will avoid that the virtual network driver disappears if the
 * remote host reboots or shuts down, the reconnect will be tried on each new incoming
 * request on the virtual adapter  - default is off */
#define MEDIA_NETWORK_RECOVERY 77
#define MEDIA_RECOVERY_OFF 0 // default,
#define MEDIA_RECOVERY_ON 1


#define MEDIA_SET_RC_LAYOUT 78 //uint8_t ptr layout

#define MEDIA_GET_RC_LAYOUT 79 //uint8_t ptr layout
/* 0 .. flat remote control */
/* 1 .. VCR remote control */
/* returns -1 if custom layout is configured */

#define FE_SET_TRANSFER_PACKETS 80

// this is mainly used for android to avoid IPC
#define VIDIOC_G_LOCALBUFFER 81 // void *

#define VIDIOC_S_VCR 82 // uint8_t 1 on .. 0 .. off (default)

/* Closed Captioning Interface, all three commands take the same parameter media_cclist */
/* get detected channel list */
#define VIDIOC_G_CCLIST 83
/* force rendering of given channel map */
#define VIDIOC_S_CCCH 84
/* get current rendering setup */
#define VIDIOC_G_CCCH 85
struct media_cclist {
	uint8_t cc1:1;
	uint8_t cc2:1;
	uint8_t cc3:1;
	uint8_t cc4:1;
	uint8_t t1:1;
	uint8_t t2:1;
	uint8_t t3:1;
	uint8_t t4:1;
} __attribute__((packed));

/* uint32_t argument value will block TS stream after changing the channel for N milliseconds */
#define FE_SET_TS_SETTLE_TIMEOUT 86

#define MEDIA_CMD_LOCK_ADAPTER 87

struct media_fe_device {
	uint8_t cmd;
	uint8_t node[50];
	uint8_t disabled;
} __attribute__((packed));

#define FE_GET_DEVICE_MODE 88

#define FE_SET_DVR_AUTOSTART 89 /* this will cause the transfer to be enabled/disabled by
				   opening/closing the frontend device */


#define MEDIA_CMD_SET_VOLTAGE 90 /* set voltage */
#define MEDIA_CMD_GET_VOLTAGE 91
struct media_device_voltage {
	uint8_t deviceid;
	uint8_t voltage;
	uint8_t rv;
#define MEDIA_VOLTAGE_5V_OFF 0
#define MEDIA_VOLTAGE_5V_ON  1
} __attribute__((packed));


#define VIDIOC_G_WSS 92

struct media_wss_data {
	uint8_t aspect_ratio; 
/* other values are currently not implemented, can be supplied uppon request */
	uint8_t b04;
	uint8_t b05;
	uint8_t b06;
	uint8_t b07;
	uint8_t b08;
	uint8_t subtitles;
	uint8_t b11;
	uint8_t b12;
	uint8_t b13;
} __attribute__((packed));

/* enable or disable wss decoding in driver */
#define VIDIOC_CONFIGURE_WSS 93

struct media_wss_cfg {
	uint8_t enabled;
};


/* this command is used for forwarding environment variables from the
   user to the driver

   eg. XDG_RUNTIME_DIR for the in-driver playback client
*/
#define VIDIOC_S_ENV 94

struct media_env {
	uint8_t key[100];
	uint8_t value[100];
} __attribute__((packed));

#define FE_SCAN_SETUP 95
struct dvb_scan_setup {
	uint32_t seekBWHz; 
	/* this can be used to finetune DVB-T/T2 stepping frequency */
	uint32_t seekStepHz; /* <- this is unused at the moment */
	uint32_t minSRbps;
	uint32_t maxSRbps;
	uint32_t minRSSIdBm;
	uint32_t maxRSSIdBm;
	uint32_t minSNRHalfdB;
	uint32_t maxSNRHalfdB;
	uint32_t rangeMin;
	uint32_t rangeMax;
	uint32_t bandwidth;
	uint8_t countrycode_set;
	uint8_t countrycode[2];
	uint8_t default_setup; /* use default setup stored in the driver,
	                          overwrite all other values */
} __attribute__((packed));

#define FE_SCAN_NEXT_FREQUENCY 96
struct dvb_scan_parameters {
	uint32_t frequency;
	uint32_t symbol_rate_bps;
	uint32_t bandwidth_Hz;
	uint16_t dvb_t2_num_plp;
	uint32_t modulation;
	uint16_t stream;
	uint32_t delivery_system;

	uint32_t timeout;
	uint8_t status; /* do not clear the lock status when running
	                   the scan loop, you're allowed to clear the struct
			   before running SCAN_NEXT_FREQUENCY the first time */
#define FE_SCAN_LOCKED    1
#define FE_SCAN_SEARCHING 2
#define FE_SCAN_ERROR     4
#define FE_SCAN_COMPLETE  8
} __attribute__((packed));

#define FE_SCAN_STATUS 97
/* parameter struct dvb_scan_parameters */

#define MEDIA_CMD_FE_DEVICE_INFO 98
struct media_fe_device_status {
	uint8_t deviceid;
	uint8_t subid;
	uint8_t status;
#define MEDIA_FE_ACTIVE  0
#define MEDIA_FE_STANDBY 1
	uint8_t lnbstatus;
#define MEDIA_LNB_POWER_ON    1
#define MEDIA_LNB_POWER_AC    2
#define MEDIA_LNB_STATUS_OK   4
} __attribute__((packed));


#define FE_ENUM_VOLTAGE_LEVELS  99
struct media_lnb_voltage {
	uint16_t id;
	uint8_t vmode;
	uint16_t voltage; /* 132 = 13.2V */
} __attribute__((packed));

#define FE_GET_VOLTAGE_LEVEL 100
#define FE_SET_VOLTAGE_LEVEL 101

#define FE_ENUM_CURRENT_LIMIT  102
struct media_current_limit {
	uint16_t id;
	uint16_t limit;
} __attribute__((packed));
#define FE_GET_CURRENT_LIMIT 103
#define FE_SET_CURRENT_LIMIT 104

#define FE_GET_TONE_MODE 105

#define FE_SET_TONE_MODE 106
#define TONE_MODE_ABOVE_VOUT  1
#define TONE_MODE_MIDDLE_VOUT 2
#define TONE_MODE_BELOW_VOUT  3

#define FE_SAVE_LNB_SETTINGS 107

#define FE_READ_CNR 108

/* only available in debug builds */
#define MEDIA_TRACER_DUMP 109

/* uint8_t */
#define FE_READ_SAT_QUALITY 110

#define DAB_GET_SERVICE 111
struct dab_service {
	uint8_t id;
	uint8_t service_name[17];
	uint32_t sid;
	uint16_t comp[10];
	int8_t n_comp;
} __attribute__((packed));


#define DAB_SCAN_SETUP 112
struct dab_scan_setup {
	uint32_t seekBWHz; 
	/* this can be used to finetune DVB-T/T2 stepping frequency */
	uint32_t seekStepHz; /* <- this is unused at the moment */
	uint32_t minSRbps;
	uint32_t maxSRbps;
	uint32_t minRSSIdBm;
	uint32_t maxRSSIdBm;
	uint32_t minSNRHalfdB;
	uint32_t maxSNRHalfdB;
	uint32_t rangeMin;
	uint32_t rangeMax;
	uint8_t default_setup; /* use default setup stored in the driver,
	                          overwrite all other values */
} __attribute__((packed));

#define DAB_SCAN_NEXT_FREQUENCY 113
struct dab_scan_parameters {
	uint32_t frequency;
	uint32_t symbol_rate_bps;
	uint32_t bandwidth_Hz;
	uint32_t delivery_system;
	uint32_t timeout;
	uint8_t scan_index;
	uint8_t status; /* do not clear the lock status when running
	                   the scan loop, you're allowed to clear the struct
			   before running SCAN_NEXT_FREQUENCY the first time */
#define DAB_SCAN_LOCKED    1
#define DAB_SCAN_SEARCHING 2
#define DAB_SCAN_ERROR     4
#define DAB_SCAN_COMPLETE  8

} __attribute__((packed));

#define FE_SET_UNICABLE 114
struct unicable_setup {
	uint32_t uc_freq;
	uint8_t uc_scr;
	uint8_t uc_enable;
	uint8_t uc_version;
	/* currently supported v1 and v2 */
} __attribute__((packed));

#define FE_GET_UNICABLE 115

#define VIDIOC_G_RADIO_SIGSTAT 116
struct v4l2_radio_sigstat {
        int8_t RSSI;
	int8_t SNR;
        uint8_t MULT;
        uint8_t VALID;
        uint32_t READFREQ;
        uint8_t HDLEVEL;
        uint8_t SNRHINT;
        uint8_t SNRLINT;
        uint8_t RSSIHINT;
        uint8_t RSSILINT;
        uint8_t BLTF;
        int8_t FREQOFF;
        uint8_t AFCRL;
        uint16_t READANTCAP;
} __attribute__((packed));

#define MEDIA_SET_UAC 117
#define MEDIA_SET_HID 118

#define DAB_GET_DIGITAL_SERVICE_DATA 119

struct dab_service_data {
//	uint8_t dls[129]; /* first two bytes are header, 7.4.5.2 /en_300401v010401o.pdf, 128 + '0' */
	uint8_t status;
/* request status, will return dls/dls_plus/mot_header/mot_body length */
	uint8_t type;
#define DLS 1
#define MOT 2
	uint16_t len;
	uint8_t bufq; /* how many items are in device queue */
	uint8_t data[0];
} __attribute__((packed));

#define DAB_GET_COMPONENT_INFO 120

#define DAB_GET_SUBCHAN_INFO 121

#define FM_SCAN_SETUP 122
struct fm_scan_setup {
	uint8_t default_setup;
} __attribute__((packed));

#define FM_SCAN_NEXT_FREQUENCY 123
struct fm_scan_parameters {
        int8_t RSSI;
	int8_t SNR;
        uint8_t MULT;
        uint8_t VALID;
        uint32_t READFREQ;
	uint8_t status;
#define FM_SCAN_LOCKED 1
#define FM_SCAN_SEARCHING 2
#define FM_SCAN_ERROR 4
#define FM_SCAN_COMPLETE 8
} __attribute__((packed));

#define FM_RDS_STATUS 124
struct fm_rds_data {
	uint8_t rdssync; /* rds synchronized */
	uint8_t pivalid; /* program identification */
	uint8_t tpptyvalid; /* traffic program  / program type*/
	uint16_t PI; /* program identification */
	uint8_t PTY; /* program type */
	uint8_t data[8];
} __attribute__((packed));

#define DEVICE_GET_MODE 125
struct device_mode {
	uint32_t capabilities;
	uint32_t current_mode;
} __attribute__((packed));

#define FE_DEBUG 126

#define MEDIA_USE_SOCKET 127 // uint8

struct dab_ensemble_info {
	uint8_t global_id;
	uint8_t lang;
	uint8_t charset_id;
	uint8_t label[17]; // last one ends with \0
} __attribute__((packed));
#define DAB_GET_ENSEMBLE_INFO 128

struct dab_time {
	uint16_t year;
	uint8_t months;
	uint8_t days;
	uint8_t hours;
	uint8_t minutes;
	uint8_t seconds;
} __attribute__((packed));
#define DAB_GET_TIME 129


/*****************  end extended ioctls ************************/
struct media_ir_config {
	uint8_t protocol;
#define IR_PROTO_NEC        0
#define IR_PROTO_RC5        1
#define IR_PROTO_RC6_MODE0  2 
#define IR_PROTO_RC6_MODE6A 3
	uint8_t nec_parity; /* currently unused */
	uint8_t rc6_mode;   /* currently unused */
} __attribute__ ((packed));

struct media_ir_enum {
	uint8_t id;
	uint8_t active;
	uint8_t protocol;
	uint8_t name[50];
} __attribute__ ((packed));


struct media_ir_keycode {
	uint8_t key[5];
	uint32_t timestamp;
} __attribute__((packed));

/* Frontend device modes */
#define MEDIA_FE_DEFAULT 0 /* init or old mode */
#define MEDIA_FE_DEFAULT_DIGITAL 1
#define MEDIA_FE_DEFAULT_ANALOG  2
#define MEDIA_FE_DVBT  3
#define MEDIA_FE_DVBC  4
#define MEDIA_FE_DVBS  5
#define MEDIA_FE_RADIO 6
#define MEDIA_FE_ATV_PAL_BG   7
#define MEDIA_FE_ATV_SECAM_BG 8
#define MEDIA_FE_ATV_NTSC_M   9
#define MEDIA_FE_ATV_PAL_I    10
#define MEDIA_FE_ATV_PAL_M    11
#define MEDIA_FE_ATV_PAL_DK   12
#define MEDIA_FE_ATV_SECAM_L  13
#define MEDIA_FE_ATV_SECAM_LC 14
#define MEDIA_FE_ISDBT 15
#define MEDIA_FE_DEFAULT_FM 16
#define MEDIA_FE_DVBT2 17
#define MEDIA_FE_ISDBS 18
#define MEDIA_FE_ATSC  19
#define MEDIA_FE_ATV_SECAM_H 20
#define MEDIA_FE_DAB 21
/* etc */
struct media_reply {
	uint8_t type;
#define MEDIA_REPLY  1
	uint32_t retval;
#define MEDIA_OK     0
#define MEDIA_UNIMPL 1
} __attribute__ ((packed));

struct media_client_open {
	uint8_t cmd;
	uint32_t size;
	uint32_t controlfd;
	uint8_t node[100];
	pid_t pid;
} __attribute__ ((packed));

#define MEDIA_DEVICE_UNSUPPORTED 1
#define MEDIA_DEVICE_INVALID     2

struct ioctl32 {
	uint32_t ioctl32;
	uint32_t ioctl64;
};

struct ioctl64 {
	uint64_t ioctl64;
};

struct media_client_ioctl {
	uint8_t cmd;
	uint32_t ioctl32;
	uint16_t size;
	int32_t retval;
} __attribute__ ((packed));

struct media_device_select {
	uint8_t cmd;
	uint8_t id;
};

struct media_device_enum {
	uint8_t cmd;
	uint8_t id;
	uint8_t subid;
	uint32_t retval;
	uint32_t capabilities;
#define MEDIA_ANALOG_TV     0x1
#define MEDIA_DVBT          0x2
#define MEDIA_DVBC          0x4
#define MEDIA_ISDBT         0x8
#define MEDIA_DIGITAL_TV    0x1008e /* mask of dvb-t dvbc and isdb-t */
#define MEDIA_AUDIO         0x10
#define MEDIA_VBI           0x20
#define MEDIA_RADIO         0x40
#define MEDIA_ATSC          0x80
                           
#define MEDIA_DVR_READER    0x100
#define MEDIA_DEMUX         0x200
#define MEDIA_REMOTE        0x400
#define MEDIA_ALSAD         0x800
#define MEDIA_OSS           0x1000
#define MEDIA_RDS           0x2000
#define MEDIA_DIGITAL_CI    0x4000
#define MEDIA_DIGITAL_CA    0x8000
#define MEDIA_DVBS2         0x10000
                           
#define MEDIA_LOOPBACK      0x20000
#define MEDIA_ULOOPBACK     0x40000
#define MEDIA_FRONTEND      0x80000
#define MEDIA_REMOTE_DEVICE 0x100000 /* indicates a network based device */
#define MEDIA_SWENCODER     0x200000
#define MEDIA_DMBT          0x400000

#define MEDIA_ALSA_REF      0x800000
#define MEDIA_DAB           0x1000000
#define MEDIA_DVBT2         0x2000000
#define MEDIA_DVBC2         0x4000000
#define MEDIA_DVBS2X        0x8000000
	uint32_t current_mode;
	uint8_t device_status;
#define DEVICE_STANDBY 0
#define DEVICE_ACTIVE  1
	uint8_t fe_status;
#define FE_STANDBY 0
#define FE_ENABLED  1
	uint8_t lnb_status;
#define FE_LNB_STATUS    1
#define FE_LNB_ON        2
#define FE_LNB_POWER_AC  4
#define FE_LNB_STATUS_OK 8
	/* currently set up delivery system */
	uint32_t delivery_system;
	uint8_t serial[100];
	uint8_t devicename[100];
	uint8_t analog_node[50];
	uint8_t radio_node[50];
	uint8_t dsp_node[50];
	uint8_t vbi_node[50];
	uint8_t demux_node[50];
	uint8_t dvr_node[50];
	uint8_t ngdvr_node[50]; // using this internally more or less
	uint8_t frontend_node[50];
	uint8_t net_node[50];
	uint8_t remote_node[50];
	uint8_t rds_node[50];
	uint8_t audio_playback_node[50];
	uint8_t audio_capture_node[50];
	uint8_t alsa_control_node[50];
	uint8_t alsa_playback_node[50];
	uint8_t alsa_capture_node[50];
	uint8_t alsa_hw[50];
	uint8_t dab_node[50];
	uint8_t ci_node[50];
	uint8_t ca_node[50];
	uint8_t networkpath[100];
	char devpath[16];
	int16_t busid;
} __attribute__ ((packed));

struct media_client_return {
	uint8_t cmd;
	int32_t retval;
	uint8_t *data;
} __attribute__ ((packed));

/* this is a mess due the limitation of the linuxdvb API... */
struct fe_device_mode {
	uint8_t mode;
	uint8_t reserved[1];
} __attribute__ ((packed)); /* PACKED IF MORE ELEMENTS ARE THERE  __attribute__ ((packet)); */

struct media_ping {
	uint8_t cmd;
};

struct media_mmap {
	uint8_t cmd;
	uint32_t shmsize;
	uint32_t key;
} __attribute__((packed));

struct media_rb_info {
        uint32_t left;
        uint32_t right;
        uint32_t buffer_size;
        uint8_t update;
	uint8_t init;
	uint8_t stop;
} __attribute__((packed));

struct media_transfer_rb {
	uint32_t left;
	uint32_t right;
	uint32_t buffer_size;
	uint8_t update;
	uint8_t stopped;
} __attribute__((packed));

/* REMOTE CONTROL */

/* further formats will have an increased version number */
struct media_rc {
	uint8_t snc[3]; /* SNC */
	uint8_t version;
#define MEDIA_RC_FORMAT_1   1
#define MEDIA_RC_FORMAT_RAW 2
	uint16_t keycode;
	uint8_t repeat;
	uint8_t buflen;
	uint8_t buffer[30];
} __attribute__((packed));
#ifdef __cplusplus
}
#endif
#endif
